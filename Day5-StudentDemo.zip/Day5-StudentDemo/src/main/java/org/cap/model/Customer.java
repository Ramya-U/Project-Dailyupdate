package org.cap.model;

public class Customer {
private String customerName;
private int customerId;
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
@Override
public String toString() {
	return "Customer [customerName=" + customerName + ", customerId=" + customerId + "]";
}
public Customer(String customerName, int customerId) {
	super();
	this.customerName = customerName;
	this.customerId = customerId;
}

}
