package org.cap.service;

import java.util.List;





public interface FeedBackService {
	public List<org.cap.model.FeedBack> getAll();

	public void save(org.cap.model.FeedBack comment);

}
