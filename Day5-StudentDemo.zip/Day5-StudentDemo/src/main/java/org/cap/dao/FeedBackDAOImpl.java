package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.FeedBack;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("feedbackdao")
@Transactional
public class FeedBackDAOImpl implements FeedBackDAO {

	@PersistenceContext
	private EntityManager entityManager;
	public List<FeedBack> getAll() {

		List<FeedBack> comments
				= entityManager.createQuery("from FeedBack").getResultList();
		return comments;
	}

	public void save(FeedBack comment) {
		// TODO Auto-generated method stub
		entityManager.persist(comment);
	}

}
