package org.cap.dao;


import java.util.List;

import org.springframework.stereotype.Repository;


public interface FeedBackDAO {
	public List<org.cap.model.FeedBack> getAll();

	public void save(org.cap.model.FeedBack comment);

}
