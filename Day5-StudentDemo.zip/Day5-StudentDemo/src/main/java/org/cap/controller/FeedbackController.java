package org.cap.controller;


import java.util.List;


import org.cap.model.FeedBack;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@Controller

public class FeedbackController {
	 @Autowired
		private org.cap.service.FeedBackService feedbackservice;
	 private FeedBack feedback;
	 @RequestMapping("/")
	 public String getPage() {
		 return "feedback1";
	 }
	 
	 
	/* @RequestMapping("/comment")
		public ResponseEntity<List<FeedBack>> getAllComments(){
			List<FeedBack> comment= feedbackservice.getAll();
			if(comment.isEmpty()||comment==null)
				return new ResponseEntity("Sorry!  details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<FeedBack>>(comment,HttpStatus.OK);
		}*/
		
	 @RequestMapping("/")
		public String getPilotForm(ModelMap map) {
			List<FeedBack> pilots= feedbackservice.getAll();
			
			map.put("fd",pilots);
			
			map.put("feedback", new FeedBack());
						return "feedbackForm";
		}

		@PostMapping("/saveComments")
		public String createComment(@RequestBody FeedBack comment){
			feedbackservice.save(comment);
			return "feedbackForm";
		}
	
		}



