package com.cap.feedback1.service;

import java.util.List;

import com.cap.feedback1.bean.Feedback1;

public interface Feedback1Service {

	void add(Feedback1 comment);

	List<Feedback1> all(int prod_Id);

}
