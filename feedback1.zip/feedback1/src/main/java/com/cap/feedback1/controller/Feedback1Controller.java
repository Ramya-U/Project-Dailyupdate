package com.cap.feedback1.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.cap.feedback1.bean.Feedback1;
import com.cap.feedback1.service.Feedback1Service;

public class Feedback1Controller {

private Feedback1Service feedback1service;
	  public List<Feedback1> allComments(int prod_Id) {
	        return feedback1service.all(prod_Id);
	    }
	    public String addComment(Feedback1 comment) {
	        /*//get the username
	        HttpServletRequest request = (HttpServletRequest) javax.faces.context.FacesContext.getCurrentInstance().getExternalContext().getRequest();
	        HttpSession session = request.getSession();
	        User user = (User) session.getAttribute("user");
	        //get id product 
*/	       
	    	
	    	
	    	Map<String, String> parameterMap = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
	        String param = parameterMap.get("idproject");
	        int prod_Id = Integer.parseInt(param);

	        comment.setProd_Id(prod_Id);
	   
	    
	        feedback1service.add(comment);
	        
	        return "/visiteur/produitdetail?id=" + prod_Id + "&faces-redirect=true";
	    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
