package com.cap.feedback1.dao;

import java.util.List;

import com.cap.feedback1.bean.Feedback1;

public interface Feedback1DAO {
	
	void add(Feedback1 comment);

	List<Feedback1> all(int prod_Id);

	 
}
