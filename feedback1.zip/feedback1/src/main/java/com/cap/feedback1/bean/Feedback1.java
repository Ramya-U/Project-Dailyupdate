package com.cap.feedback1.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Feedback1 {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int feedback_Id;
	private long prod_Id;
	private long cust_Id;
	private int prod_Rating;
	private String comments;
	
	public long getProd_Id() {
		return prod_Id;
	}
	public void setProd_Id(long prod_Id) {
		this.prod_Id = prod_Id;
	}
	public long getCust_Id() {
		return cust_Id;
	}
	public void setCust_Id(long cust_Id) {
		this.cust_Id = cust_Id;
	}
	public int getProd_Rating() {
		return prod_Rating;
	}
	public void setProd_Rating(int prod_Rating) {
		this.prod_Rating = prod_Rating;
	}
	public int getFeedback_Id() {
		return feedback_Id;
	}
	
	/*
	public void setFeedback_Id(int feedback_Id) {
		this.feedback_Id = feedback_Id;
	}
	*/
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "Feedback1 [prod_Id=" + prod_Id + ", cust_Id=" + cust_Id + ", prod_Rating=" + prod_Rating
				+ ", feedback_Id=" + feedback_Id + ", comments=" + comments + "]";
	}
	public Feedback1(long prod_Id, long cust_Id, int prod_Rating, int feedback_Id, String comments) {
		super();
		this.prod_Id = prod_Id;
		this.cust_Id = cust_Id;
		this.prod_Rating = prod_Rating;
		this.feedback_Id = feedback_Id;
		this.comments = comments;
	}
	public Feedback1() {
		super();
	}
	
	
	
}
