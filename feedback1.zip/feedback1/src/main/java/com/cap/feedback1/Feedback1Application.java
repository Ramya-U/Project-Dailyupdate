package com.cap.feedback1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Feedback1Application {

	public static void main(String[] args) {
		SpringApplication.run(Feedback1Application.class, args);
	}
}
