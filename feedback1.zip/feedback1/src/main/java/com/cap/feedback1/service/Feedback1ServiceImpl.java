package com.cap.feedback1.service;

import java.util.List;

import com.cap.feedback1.bean.Feedback1;
import com.cap.feedback1.dao.Feedback1DAO;

public class Feedback1ServiceImpl implements Feedback1Service {
	private Feedback1DAO feedbackdao;

	@Override
	public void add(Feedback1 comment) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Feedback1> all(int prod_Id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/*
	  @Autowired
	    private ReviewRepository reviewRepository;

	    public Page<Review> findByProductId(long productId, int pageNumber, int pageSize) {
	        return reviewRepository.findByProductId(productId, new PageRequest(pageNumber, pageSize));
	    }

	    public Review save(Review review) {
	        return reviewRepository.save(review);
	    }
*/
}
