package com.cap.feedback1.dao;

import java.util.List;

import com.cap.feedback1.bean.Feedback1;

public class Feedback1DAOImpl implements Feedback1DAO {

	@Override
	public void add(Feedback1 comment) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Feedback1> all(int prod_Id) {
		// TODO Auto-generated method stub
		return null;
	}
/*
	 public static void add(Commentaire commentaire){
	        String sql  = "insert into commentaire(idProduit , txt ,login) values (? , ? ,?) " ;
	        try {
	            PreparedStatement st = Connexion.getConnection().prepareStatement(sql) ;
	            st.setInt(1, commentaire.getIdProduit());
	            st.setString(2, commentaire.getTxt());
	            st.setString(3, commentaire.getLogin());
	            st.executeUpdate();
	        } catch (SQLException ex) {
	            Logger.getLogger(CommentaireModel.class.getName()).log(Level.SEVERE, null, ex);
	        }
	    }
	
	
 public static List<Commentaire> all(int idProduit){
         
         List<Commentaire> lst = new ArrayList<>() ;
         Commentaire c  ;
         String sql = "select * from commentaire where idProduit = ?  " ;
        try {
            PreparedStatement st = Connexion.getConnection().prepareStatement(sql) ;
            st.setInt(1, idProduit);
            ResultSet rs = st.executeQuery() ; 
            while(rs.next()){
                c = new Commentaire() ;
                c.setIdComment(rs.getInt("idComment"));
                c.setIdProduit(rs.getInt("idProduit"));
                c.setLogin(rs.getString("login")) ;
                c.setTxt(rs.getString("txt")) ;
                c.setDateCommentaire(rs.getDate("dateCommentaire")) ;
                lst.add(c);
            }
        } catch (SQLException ex) {
            Logger.getLogger(CommentaireModel.class.getName()).log(Level.SEVERE, null, ex);
        }
         return lst ;
     }*/
	
}
