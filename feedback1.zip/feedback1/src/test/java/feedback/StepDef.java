package feedback;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	
	@Given("^Product Page$")
	public void product_Page() throws Throwable {
	   
	}

	@When("^Customer Purchased any product$")
	public void customer_Purchased_any_product() throws Throwable {
	   
	}

	@When("^Purchased date not more than (\\d+) days$")
	public void purchased_date_not_more_than_days(int arg1) throws Throwable {
	    
	}

	@Then("^Customer can give feedback$")
	public void customer_can_give_feedback() throws Throwable {
	   
	}

}
